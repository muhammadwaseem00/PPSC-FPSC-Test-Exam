﻿class test4 
{
    public int FindOccurrence(int[] array, int target)
    {
        if (array == null)
        {
            throw new ArgumentNullException(nameof(array), "Input array is null.");
        }

        int occurrence = 0;
        foreach (int number in array)
        {
            if (number == target)
            {
                occurrence++;
            }
        }

        return occurrence;
    }

    // Module: Calculate Summation of Even Numbers in an Array
    public int SumEvenNumbers(int[] array)
    {
        if (array == null)
        {
            throw new ArgumentNullException(nameof(array), "Input array is null.");
        }

        int sum = 0;
        foreach (int number in array)
        {
            if (number % 2 == 0)
            {
                sum += number;
            }
        }

        return sum;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        test4 numberOperations = new test4();

        int[] array = { 2, 3, 2, 5, 8, 10, 2, 5 };

        int targetNumber = 2;
        int occurrence = numberOperations.FindOccurrence(array, targetNumber);
        Console.WriteLine($"Number {targetNumber} occurs {occurrence} times in the array.");

        int sumOfEvenNumbers = numberOperations.SumEvenNumbers(array);
        Console.WriteLine($"Summation of even numbers in the array: {sumOfEvenNumbers}");
    }
}