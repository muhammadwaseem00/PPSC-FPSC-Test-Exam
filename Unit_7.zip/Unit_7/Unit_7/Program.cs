﻿using System;
using System.Diagnostics;

class Sorting
{
    // Original Bubble Sort algorithm
    public static void BubbleSort(int[] arr)
    {
        int n = arr.Length;
        bool swapped;
        do
        {
            swapped = false;
            for (int i = 1; i < n; i++)
            {
                if (arr[i - 1] > arr[i])
                {
                    // Swap arr[i-1] and arr[i]
                    int temp = arr[i - 1];
                    arr[i - 1] = arr[i];
                    arr[i] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }

    // Function to generate random data
    public static int[] GenerateRandomData(int size)
    {
        Random rand = new Random();
        int[] data = new int[size];
        for (int i = 0; i < size; i++)
        {
            data[i] = rand.Next(1000); // Adjust the range as needed
        }
        return data;
    }

    static void Main()
    {
        int[] smallData = GenerateRandomData(10);
        int[] mediumData = GenerateRandomData(1000);
        int[] largeData = GenerateRandomData(10000);

        // Baseline test with the original Bubble Sort
        Stopwatch stopwatch = new Stopwatch();
        Console.WriteLine("Baseline Testing:");

        // Small Data
        stopwatch.Start();
        BubbleSort(smallData);
        stopwatch.Stop();
        Console.WriteLine($"Small Data Sorted in {stopwatch.ElapsedMilliseconds} ms");
        stopwatch.Reset();

        // Medium Data
        stopwatch.Start();
        BubbleSort(mediumData);
        stopwatch.Stop();
        Console.WriteLine($"Medium Data Sorted in {stopwatch.ElapsedMilliseconds} ms");
        stopwatch.Reset();

        // Large Data
        stopwatch.Start();
        BubbleSort(largeData);
        stopwatch.Stop();
        Console.WriteLine($"Large Data Sorted in {stopwatch.ElapsedMilliseconds} ms");
        stopwatch.Reset();

        // Implement and test optimizations here

        Console.ReadLine();
    }
}
