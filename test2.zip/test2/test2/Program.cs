﻿// Given an array of integers, and a number of times to look, return the minimum value
public class test2
{
    public int Example1(int[] y, int z)
    {
        if (y == null || y.Length == 0 || z <= 0)
        {
            throw new ArgumentException("Invalid input parameters");
        }

        int currmin = y[0];
        for (int i = 1; i < z; i++)
        {
            if (y[i] < currmin)
            {
                currmin = y[i];
            }
        }
        return currmin;
    }

    // Given an array of integers, print out each value
    public void Example2(int[] a)
    {
        if (a == null || a.Length == 0)
        {
            throw new ArgumentException("Invalid input parameter");
        }

        foreach (int value in a)
        {
            Console.WriteLine(value);
        }
    }

    // Given two integer search values, check if they are equal to the values in the array
    public bool Example3(int[] foo, int a, int b)
    {
        if (foo == null || foo.Length == 0)
        {
            throw new ArgumentException("Invalid input parameter");
        }

        bool found = false;
        foreach (int value in foo)
        {
            if (value == a || value == b)
            {
                Console.WriteLine($"The value {value} was found in the int array.");
                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("None of the search values were found.");
        }

        return found;
    }

    public static void Main(string[] args)
    {
        test2 u4 = new test2();

        // Test Example1
        int[] list1 = { 1, 50, 200, 312 };
        int n1 = 4;
        int result1 = u4.Example1(list1, n1);
        Console.WriteLine($"Result of Example1: {result1}");

        // Test Example2
        int[] list2 = new int[100];
        for (int i = 0; i < 100; i++)
        {
            list2[i] = i + 1;
        }
        u4.Example2(list2);

        // Test Example3
        int[] list3 = { 1, 5, 7, 10 };
        bool result3 = u4.Example3(list3, 1, 5);
        Console.WriteLine($"Result of Example3: {result3}");
    }
}