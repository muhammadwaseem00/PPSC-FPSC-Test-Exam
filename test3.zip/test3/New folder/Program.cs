﻿
public class test3
{
    // Module: Find the Minimum Value in an Array
    public int FindMin(int[] array)
    {
        if (array == null || array.Length == 0)
        {
            throw new ArgumentException("Invalid input array.");
        }

        int min = array[0];

        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] < min)
            {
                min = array[i];
            }
        }

        return min;
    }

    // Given an array of integers, print out each value
    public void Example2(int[] a)
    {
        if (a == null || a.Length == 0)
        {
            throw new ArgumentException("Invalid input parameter");
        }

        foreach (int value in a)
        {
            Console.WriteLine(value);
        }
    }

    // Module: Find the Maximum Value in an Array
    public int FindMax(int[] array)
    {
        if (array == null || array.Length == 0)
        {
            throw new ArgumentException("Invalid input array.");
        }

        int max = array[0];

        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > max)
            {
                max = array[i];
            }
        }

        return max;
    }

    public static void Main(string[] args)
    {
        test3 u4 = new test3();

        // Test Example1
        

        int[] array = { 12, 45, 7, 98, 23, 56, 34 };

        // Find the minimum value
        int min =u4.FindMin(array);
        Console.WriteLine($"Minimum value: {min}");

        // Find the maximum value
        int max = u4.FindMax(array);
        Console.WriteLine($"Maximum value: {max}");
    }
}