﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

class DressingRooms
{
    private Semaphore semaphore;

    public DressingRooms(int numberOfRooms)
    {
        semaphore = new Semaphore(numberOfRooms, numberOfRooms);
    }

    public void RequestRoom()
    {
        semaphore.WaitOne();
    }

    public void ReleaseRoom()
    {
        semaphore.Release();
    }
}

class Customer
{
    public int CustomerId { get; private set; }
    public int NumberOfItems { get; private set; }

    public Customer(int customerId, int numberOfItems)
    {
        CustomerId = customerId;
        NumberOfItems = numberOfItems;
    }

    public void TryOnClothes()
    {
        // Simulate trying on clothes
        Random random = new Random();
        int timeToTryOn = random.Next(1, 4); // Random time between 1 to 3 minutes per item
        Thread.Sleep(timeToTryOn * NumberOfItems * 1000); // Sleep in milliseconds
    }
}

class Scenario
{
    private List<Customer> customers;
    private DressingRooms dressingRooms;

    public Scenario(int numberOfRooms, int numberOfCustomers)
    {
        customers = new List<Customer>();
        dressingRooms = new DressingRooms(numberOfRooms);

        // Create customers
        for (int i = 1; i <= numberOfCustomers; i++)
        {
            int randomItems = new Random().Next(1, 7); // Random items between 1 and 6
            customers.Add(new Customer(i, randomItems));
        }
    }

    public void RunScenario()
    {
        // Start customer threads
        List<Task> tasks = new List<Task>();
        foreach (Customer customer in customers)
        {
            tasks.Add(Task.Run(() =>
            {
                dressingRooms.RequestRoom();
                Console.WriteLine($"Customer {customer.CustomerId} is trying on {customer.NumberOfItems} items.");
                customer.TryOnClothes();
                dressingRooms.ReleaseRoom();
                Console.WriteLine($"Customer {customer.CustomerId} is leaving.");
            }));
        }

        Task.WhenAll(tasks).Wait(); // Wait for all customer threads to complete
    }
}

class Program
{
    static void Main()
    {
        // Create and run different scenarios
        Scenario scenario1 = new Scenario(3, 10);
        Scenario scenario2 = new Scenario(4, 15);
        Scenario scenario3 = new Scenario(5, 20);

        scenario1.RunScenario();
        scenario2.RunScenario();
        scenario3.RunScenario();

        // Calculate and print results
        // You can calculate and print various metrics here
    }
}
